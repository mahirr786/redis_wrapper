package com.redisWrapper.lock;

import io.lettuce.core.ScriptOutputType;
import io.lettuce.core.api.sync.RedisCommands;
import java.time.Duration;
import java.util.UUID;

public class SimpleLockClient implements LockClient {

    private final RedisCommands<String, String> cmd;

    public SimpleLockClient(RedisCommands<String, String> cmd) {
        this.cmd = cmd;
    }

    @Override
    public AutoCloseable tryLock(String key, Duration ttl) {
        String token = UUID.randomUUID().toString();
        String ok = cmd.set(key, token, io.lettuce.core.SetArgs.Builder.nx().px(ttl.toMillis()));

        boolean acquired = "OK".equals(ok);

        return new AutoCloseable() {
            @Override
            public void close() {
                if (!acquired) return;
                String lua = """
                    if redis.call('get', KEYS[1]) == ARGV[1] then
                        return redis.call('del', KEYS[1])
                    else
                        return 0
                    end
                    """;
                cmd.getStatefulConnection().sync()
                        .eval(lua, ScriptOutputType.INTEGER, new String[]{key}, token);
            }
        };
    }
}
