package com.redisWrapper.web;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class SmokeController {

    @GetMapping("/ping")
    public String ping() {
        return "Redis Wrapper is running!";
    }
}
