package com.redisWrapper.kv;

import java.time.Duration;
import java.util.Optional;

public interface RedisKV {
    <T> Optional<T> get(String key, Class<T> type);
    <T> void set(String key, T value);
    <T> void set(String key, T value, Duration ttl);
    boolean delete(String key);
    boolean exists(String key);
}
