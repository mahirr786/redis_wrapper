package com.redisWrapper.kv;

import com.fasterxml.jackson.databind.ObjectMapper;
import io.lettuce.core.api.sync.RedisCommands;

import java.time.Duration;
import java.util.Optional;

public class LettuceRedisKV implements RedisKV {

    private final RedisCommands<String, String> cmd;
    private final ObjectMapper om = new ObjectMapper();

    public LettuceRedisKV(RedisCommands<String, String> cmd) {
        this.cmd = cmd;
    }

    @Override
    public <T> Optional<T> get(String key, Class<T> type) {
        String s = cmd.get(key);
        if (s == null) return Optional.empty();
        try {
            return Optional.of(om.readValue(s, type));
        } catch (Exception e) {
            throw new RuntimeException("Deserialize failed for " + key, e);
        }
    }

    @Override
    public <T> void set(String key, T value) {
        try {
            cmd.set(key, om.writeValueAsString(value));
        } catch (Exception e) {
            throw new RuntimeException("Serialize failed for " + key, e);
        }
    }

    @Override
    public <T> void set(String key, T value, Duration ttl) {
        try {
            cmd.setex(key, ttl.toSeconds(), om.writeValueAsString(value));
        } catch (Exception e) {
            throw new RuntimeException("Serialize failed for " + key, e);
        }
    }

    @Override
    public boolean delete(String key) {
        return cmd.del(key) > 0;
    }

    @Override
    public boolean exists(String key) {
        return cmd.exists(key) > 0;
    }
}
