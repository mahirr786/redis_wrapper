package com.redisWrapper.cache;

import com.redisWrapper.kv.RedisKV;
import java.time.Duration;

public class DefaultCacheHelper implements CacheHelper {

    private final RedisKV kv;

    public DefaultCacheHelper(RedisKV kv) {
        this.kv = kv;
    }

    @Override
    public <T> T getOrLoad(String key, Duration ttl, Class<T> type, java.util.function.Supplier<T> loader) {
        return kv.get(key, type).orElseGet(() -> {
            T value = loader.get();
            kv.set(key, value, ttl);
            return value;
        });
    }
}
