package com.redisWrapper.cache;

import java.time.Duration;
import java.util.function.Supplier;

public interface CacheHelper {
    <T> T getOrLoad(String key, Duration ttl, Class<T> type, Supplier<T> loader);
}
