package com.redisWrapper.lock;

import java.time.Duration;

public interface LockClient {
    AutoCloseable tryLock(String key, Duration ttl);
}
